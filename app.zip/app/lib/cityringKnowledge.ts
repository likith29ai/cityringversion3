export const CITYRING_KNOWLEDGE = `
ABOUT CITYRING:
Cityring is a digital community platform where people can discover and join curated groups called Rings. 
These Rings are built around interests, networking goals, cities, and preferred communication platforms like WhatsApp, Instagram, Telegram, and Email.

PURPOSE:
Cityring helps people build meaningful connections online by joining communities that match their interests, goals, and communication preferences.

WHO CAN JOIN:
Anyone looking to network, build relationships, collaborate, learn, grow professionally, or become part of active digital communities can join Cityring.

BENEFITS OF JOINING:
- Connect with like-minded people
- Discover communities based on interests
- Access curated Rings
- Find networking opportunities
- Join premium and exclusive communities
- Collaborate with others
- Build valuable digital connections
- Become part of trusted groups

WHAT ARE RINGS:
Rings are curated communities inside Cityring.
Each Ring may focus on a topic, industry, city, networking type, or platform preference.
Users can request to join Rings based on their membership eligibility.

EXCLUSIVE RINGS:
Exclusive Rings are premium curated communities with special access, limited membership, and higher-value networking opportunities.

MEMBERSHIP:
Users choose a membership plan to unlock joining privileges.
Higher plans allow access to more Rings and premium experiences.

PAYMENT APPROVAL:
After payment, Cityring verifies the membership manually or through admin approval before full access is activated.

SAFETY:
Cityring focuses on curated communities, controlled access, and structured membership to create better and more meaningful networking spaces.

SUPPORT:
Users can contact support or use Cityring Assistant for help with memberships, joining Rings, approvals, or account questions.
`;
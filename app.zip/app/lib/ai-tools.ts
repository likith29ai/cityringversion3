import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

function cleanSearchQuery(query: string) {
  return query
    .toLowerCase()
    .replace(/show|find|groups|group|rings|ring|communities|community|available|for|people|from/gi, "")
    .trim();
}

export async function searchGroups(query: string) {
  const clean = cleanSearchQuery(query);

  console.log("SEARCH TERM:", clean);

  const { data, error } = await supabase
    .from("groups")
    .select("*")
    .or(
      `title.ilike.%${clean}%,city.ilike.%${clean}%,interest.ilike.%${clean}%,description.ilike.%${clean}%`
    )
    .limit(5);

  if (error) {
    console.error(error);
    return [];
  }

  return data;
}
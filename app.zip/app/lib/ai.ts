import OpenAI from "openai";
import { CITYRING_KNOWLEDGE } from "./cityringKnowledge";
import { searchGroups } from "./ai-tools";
import { detectIntent } from "./intent";

const client = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENROUTER_API_KEY,
});

export async function askCityringAI(message: string) {
  try {
    // STEP 1 — AI understands intent
    const intentData = await detectIntent(message);

    console.log("INTENT:", intentData);

    // STEP 2 — GROUP SEARCH
    if (intentData.intent === "group_search") {
      const searchText = `
        ${intentData.city || ""}
        ${intentData.interest || ""}
      `;

      const groups = await searchGroups(searchText);

      if (!groups.length) {
        return `I couldn't find matching rings right now.

Try searching with:
- sports
- startup
- business
- bengaluru
- mysore`;
      }

      const formatted = groups
        .map(
          (g: any, i: number) =>
            `${i + 1}. ${g.title}

📍 ${g.city}
🎯 ${g.interest}`
        )
        .join("\n\n");

      return `I found these matching rings:\n\n${formatted}`;
    }

    // STEP 3 — NORMAL AI CHAT
    const completion = await client.chat.completions.create({
      model: "openrouter/free",

      messages: [
        {
          role: "system",
          content: `
You are Cityring Assistant.

${CITYRING_KNOWLEDGE}

Rules:
- Answer naturally
- Keep answers conversational
- Be friendly
- Only answer Cityring-related questions
- If unclear, ask follow-up questions
`,
        },

        {
          role: "user",
          content: message,
        },
      ],
    });

    return (
      completion.choices[0].message.content ||
      "Sorry, I couldn't answer."
    );
  } catch (error) {
    console.error("AI ERROR:", error);

    return "Cityring Assistant is temporarily busy.";
  }
}